<?php
require_once("cadenas.php");

$resultado = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $cadena = $_POST["cadena"];
    $opcion = $_POST["opcion"];

    switch ($opcion) {

        case "caracteres":
            $resultado = "Cantidad de caracteres: " . contarCaracteres($cadena);
            break;

        case "mayusculas":
            $resultado = "Mayúsculas: " . convertirMayusculas($cadena);
            break;

        case "minusculas":
            $resultado = "Minúsculas: " . convertirMinusculas($cadena);
            break;

        case "invertir":
            $resultado = "Cadena invertida: " . invertirCadena($cadena);
            break;

        case "palindromo":
            $resultado = esPalindromo($cadena)
                ? "Sí es un palíndromo"
                : "No es un palíndromo";
            break;

        case "vocales":
            $resultado = "Cantidad de vocales: " . contarVocales($cadena);
            break;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Funciones de Cadenas</title>
</head>
<body>

    <h2>Operaciones con Cadenas</h2>

    <form method="post">
        <label>Introduce una palabra o frase:</label><br><br>

        <input type="text" name="cadena" required size="40"><br><br>

        <select name="opcion">
            <option value="caracteres">Contar caracteres</option>
            <option value="mayusculas">Convertir a mayúsculas</option>
            <option value="minusculas">Convertir a minúsculas</option>
            <option value="invertir">Invertir cadena</option>
            <option value="palindromo">Verificar palíndromo</option>
            <option value="vocales">Contar vocales</option>
        </select>

        <br><br>

        <input type="submit" value="Ejecutar">
    </form>

    <br>

    <?php
        if ($resultado != "") {
            echo "<h3>Resultado:</h3>";
            echo $resultado;
        }
    ?>

</body>
</html>