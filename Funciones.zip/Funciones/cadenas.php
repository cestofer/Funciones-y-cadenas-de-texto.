<?php

function contarCaracteres($cadena) {
    return strlen($cadena);
}

function convertirMayusculas($cadena) {
    return strtoupper($cadena);
}

function convertirMinusculas($cadena) {
    return strtolower($cadena);
}

function invertirCadena($cadena) {
    return strrev($cadena);
}

function esPalindromo($cadena) {
    $cadena = strtolower(str_replace(' ', '', $cadena));
    return $cadena == strrev($cadena);
}

function contarVocales($cadena) {
    $contador = 0;
    $vocales = ['a', 'e', 'i', 'o', 'u'];

    $cadena = strtolower($cadena);

    for ($i = 0; $i < strlen($cadena); $i++) {
        if (in_array($cadena[$i], $vocales)) {
            $contador++;
        }
    }

    return $contador;
}

?>